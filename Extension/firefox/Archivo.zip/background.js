browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
	console.log(tabId, changeInfo, tab);
	// Check if the tab has finished loading and the URL matches
	if (
		changeInfo.status === "complete" &&
		tab.url === "http://127.0.0.1:35001/"
	) {
		// Close the tab
		browser.tabs.remove(tabId);
	}
});
